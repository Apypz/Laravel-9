@extends('travels.layout')

@section('content')
<img src="{{ Storage::url('public/image/' . $travel->image ) }}" alt="" style="width: 150px">
<h3>{{ $Travel->nama }}</h3>
<p>Jurusan : {{ $Travel->kota }}</p>
<p>Harga Tiket {{ $Travel->harga }}</p>
@endsection
