@extends('travels.layout')

@section('content')
<form action="{{ route('travels.update', $Travel->id) }}" method="post">

        @csrf
        @method('PUT')

            <label for="">Nama</label>
            <input type="text" name="nama" id="" value="{{ $Travel->nama }}" class="form-control">


            <label for="">Kota</label>
            <input type="text" name="kota" id="" value="{{ $Travel->kota }}" class="form-control">


            <label for="">Harga Tiket</label>
            <input type="text" name="harga_tiket" id="" value="{{ $Travel->harga_tiket }}" class="form-control">

            <label for="">Upload Gambar</label>
            <input type="file" name="image" id="">
<br>

    <input type="submit" value="Simpan" class="btn btn-success">
    </form>
@endsection
