@extends('travels.layout')

@section('content')
<form action="{{ route('travels.store') }}" method="post" enctype="multipart/form-data" class="form">

    @csrf

        <label for="">Nama</label>
        <input type="text" name="nama" id="" class="form-control">


        <label for="">Kota</label>
        <input type="text" name="kota" id="" class="form-control">


        <label for="">Harga Tiket</label>
        <input type="text" name="harga_tiket" class="form-control" id="">

        <label for="">Upload Gambar</label>
        <input type="file" name="image" id="">
        <br>

<input type="submit" value="Simpan" class="btn btn-success">
</form>
@endsection
