@extends('travels.layout')

@section('content')
<table class="table">
<a href="{{ route('travels.create') }}"><button class="btn btn-success">Tambah</button></a>
    <tr>
        <th>No</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>
    @foreach ($Travels as $Travel )
    <tr>
        <td>{{ $Travel->id }}</td>
        <td><img src="{{ Storage::url('public/images/' . $Travel->image) }}" alt="" style="width: 150px"></td>
        <td>{{ $Travel->nama }}</td>
        <td>{{ $Travel->kota }}</td>
        <td>{{ $Travel->harga_tiket }}</td>

        <td><a href="{{ route('travels.show', $Travel->id ) }}"><button class="btn btn-primary">Show</button></a>
        <a href="{{ route('travels.edit', $Travel->id ) }}"><button class="btn btn-info">Edit</button></a>
        <form onclick="return confirm('Yakin?')" action="{{ route('travels.destroy', $Travel->id) }}" method="POST" style="display: inline;">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">Delete</button>
        </form>
        </td>
    </tr>

    @endforeach
</table>
{{ $Travels->links() }}
@endsection
