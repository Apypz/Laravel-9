<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Travel;
use Illuminate\Support\Facades\Storage;

class TravelsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $Travels = Travel::paginate(2);
        return view ('travels.index', ['Travels'=>$Travels]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('travels.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'nama'=>'required',
            'kota'=>'required',
            'harga_tiket'=>'required',
            'image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);
        $image = $request->file('image');
        $image->storeAs('public/images', $image->hashName());

        Travel::create([
            'nama'=>$request->nama,
            'kota'=>$request->kota,
            'harga_tiket'=>$request->harga_tiket,
            'image'=>$image->hashName()
        ]);

        return redirect()->route('travels.index')->with('success','Berhasil Update');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Travel $travel)
    {
        //
        return view('travels.show', ['Travel'=>$travel]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Travel $travel)
    {
        //
        return view('travels.edit', ['Travel'=>$travel]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Travel $travel)
    {
        //
        $request->validate([
            'nama'=>'required',
            'kota'=>'required',
            'harga_tiket'=>'required'
        ]);

        if ($request->has('image')){
            $image = $request->file('image');
            $image->storeAs('public/images', $image->hashAnime());

            Storage::delete('public/images/' . $travel->image);

            $travel->update([
                'nama'=>$request->nama,
                'kota'=>$request->kota,
                'harga_tiket'=>$request->harga_tiket,
                'title'=>image->hashName(),
            ]);

        }else{
            $travel->update([
                'nama'=>$request->nama,
                'kota'=>$request->kota,
                'harga_tiket'=>$request->harga_tiket,
                'title'=>image->hashName(),
            ]);

        }

        $travel->update($request->all());

        return redirect()->route('travels.index')->with('success','Berhasil Update');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Travel $travel)
    {
        //
        $travel->delete();
        return redirect()->route('travels.index')->with('success','Berhasil Hapus');
    }
}
