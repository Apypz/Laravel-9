<?php $__env->startSection('content'); ?>
<table class="table">
<a href="<?php echo e(route('travels.create')); ?>"><button class="btn btn-success">Tambah</button></a>
    <tr>
        <th>No</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $Travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($Travel->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/' . $Travel->image)); ?>" alt="" style="width: 150px"></td>
        <td><?php echo e($Travel->nama); ?></td>
        <td><?php echo e($Travel->kota); ?></td>
        <td><?php echo e($Travel->harga_tiket); ?></td>

        <td><a href="<?php echo e(route('travels.show', $Travel->id )); ?>"><button class="btn btn-primary">Show</button></a>
        <a href="<?php echo e(route('travels.edit', $Travel->id )); ?>"><button class="btn btn-info">Edit</button></a>
        <form onclick="return confirm('Yakin?')" action="<?php echo e(route('travels.destroy', $Travel->id)); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Delete</button>
        </form>
        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($Travels->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/index.blade.php ENDPATH**/ ?>