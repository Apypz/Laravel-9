<table border="2">
    <td><a href="<?php echo e(route('Travels.create')); ?>"><button>Tambah</button></a></td>
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $Travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($Travel->id); ?></td>
        <td><?php echo e($Travel->nama); ?></td>
        <td><?php echo e($Travel->kota); ?></td>
        <td><?php echo e($Travel->harga_tiket); ?></td>
        <td><a href="<?php echo e(route('Travels.show')); ?>"><button>Lihat</button></a></td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /home/siswa/app_travel/resources/views/Travels/index.blade.php ENDPATH**/ ?>