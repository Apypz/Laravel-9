<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('travels.update', $Travel->id)); ?>" method="post">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

            <label for="">Nama</label>
            <input type="text" name="nama" id="" value="<?php echo e($Travel->nama); ?>" class="form-control">


            <label for="">Kota</label>
            <input type="text" name="kota" id="" value="<?php echo e($Travel->kota); ?>" class="form-control">


            <label for="">Harga Tiket</label>
            <input type="text" name="harga_tiket" id="" value="<?php echo e($Travel->harga_tiket); ?>" class="form-control">

            <label for="">Upload Gambar</label>
            <input type="file" name="image" id="">
<br>

    <input type="submit" value="Simpan" class="btn btn-success">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/edit.blade.php ENDPATH**/ ?>