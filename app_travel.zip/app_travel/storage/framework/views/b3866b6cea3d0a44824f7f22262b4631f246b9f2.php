<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('travels.store')); ?>" method="post" enctype="multipart/form-data" class="form">

    <?php echo csrf_field(); ?>

        <label for="">Nama</label>
        <input type="text" name="nama" id="" class="form-control">


        <label for="">Kota</label>
        <input type="text" name="kota" id="" class="form-control">


        <label for="">Harga Tiket</label>
        <input type="text" name="harga_tiket" class="form-control" id="">

        <label for="">Upload Gambar</label>
        <input type="file" name="image" id="">
        <br>

<input type="submit" value="Simpan" class="btn btn-success">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/create.blade.php ENDPATH**/ ?>