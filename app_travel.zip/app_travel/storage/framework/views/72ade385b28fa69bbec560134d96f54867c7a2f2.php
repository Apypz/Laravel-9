<?php $__env->startSection('content'); ?>
<h3><?php echo e($Travel->nama); ?></h3>
<p>Jurusan : <?php echo e($Travel->kota); ?></p>
<p>Harga Tiket <?php echo e($Travel->harga); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/show.blade.php ENDPATH**/ ?>