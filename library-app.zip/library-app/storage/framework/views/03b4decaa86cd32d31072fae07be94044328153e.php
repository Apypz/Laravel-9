<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('books.update', $book->id)); ?>" method="post">

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

<table class="table">
    <tr>
        <td><label for="">Title</label></td>
        <td><input type="text" name="title" id="" value="<?php echo e($book->title); ?>" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Author</label></td>
        <td><input type="text" name="author" id="" value="<?php echo e($book->author); ?>" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Page</label></td>
        <td><input type="text" name="page" id="" value="<?php echo e($book->page); ?>" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Year</label></td>
        <td><input type="text" name="year" id="" value="<?php echo e($book->year); ?>" class="form-control"></td>
    </tr>
</table>
<input type="submit" value="Update" class="btn btn-primary">
<a class="btn btn-danger" href="<?php echo e(route('books.index')); ?>">Back To Index</a>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/library-app/resources/views/books/edit.blade.php ENDPATH**/ ?>