<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('books.store')); ?>" method="post">

    <?php echo csrf_field(); ?>

<table class="table">
    <tr>
        <td><label for="">Title</label></td>
        <td><input type="text" name="title" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Author</label></td>
        <td><input type="text" name="author" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Page</label></td>
        <td><input type="text" name="page" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Year</label></td>
        <td><input type="text" name="year" id="" class="form-control"></td>
    </tr>
</table>
<input type="submit" value="Tambah" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/library-app/resources/views/books/create.blade.php ENDPATH**/ ?>