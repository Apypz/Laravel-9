<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Library Application</title>
</head>
<body>
<div class="container">
    <br>
    <h1 style="text-align: center"><strong>Library Application 😂😱 </strong></h1>
<div>
    <?php if(session()->has('Success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('Success')); ?>

    </div>

    <?php endif; ?>
</div>
    <br>

    <?php echo $__env->yieldContent('content'); ?>
<br><br>
    <footer>
        <p style="text-align: center;">Copyright &copy; AfifCoding|2022. All Right Deserved.</p>
    </footer>
</div>
</body>
</html>
<?php /**PATH /home/siswa/Desktop/library-app/resources/views/books/layout.blade.php ENDPATH**/ ?>