<?php $__env->startSection('content'); ?>
<table class="table table-striped">

    <tr class="table-dark">
        <th>Id</th>
        <th>Title</th>
        <th>Author</th>
        <th>Page</th>
        <th>Year</th>
        <th class="text-center">Action</th>
    </tr>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($b->id); ?></td>
        <td><?php echo e($b->title); ?></td>
        <td><?php echo e($b->author); ?></td>
        <td><?php echo e($b->page); ?></td>
        <td><?php echo e($b->year); ?></td>
        <td class="text-center">
            <a class="btn btn-danger" href="<?php echo e(route('books.show', $b->id)); ?>">Show</a>
            <a class="btn btn-warning" href="<?php echo e(route('books.edit', $b->id)); ?>">Edit</a>

           <form onclick="return confirm('Are you?')" action="<?php echo e(route('books.destroy', $b->id)); ?>" method="post" style="display: inline">

                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger">Delete</button>

            </form>
        </td>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<a href="<?php echo e(route('books.create')); ?>"><button class="btn btn-primary">Add</button></a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/library-app/resources/views/books/index.blade.php ENDPATH**/ ?>