<?php $__env->startSection('content'); ?>

<h1><strong><?php echo e($book->author); ?></strong></h1>

<p>Written By : <?php echo e($book->author); ?></p>
<p>Number of Pages : <?php echo e($book->page); ?></p>
<p>Published On : <?php echo e($book->year); ?></p>

<a class="btn btn-primary" href="<?php echo e(route('books.index')); ?>">Back To Index</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/library-app/resources/views/books/show.blade.php ENDPATH**/ ?>