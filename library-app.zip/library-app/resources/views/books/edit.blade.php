@extends('books.layout')

@section('content')

<form action="{{ route('books.update', $book->id) }}" method="post">

    @csrf
    @method('PUT')

<table class="table">
    <tr>
        <td><label for="">Title</label></td>
        <td><input type="text" name="title" id="" value="{{ $book->title }}" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Author</label></td>
        <td><input type="text" name="author" id="" value="{{ $book->author }}" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Page</label></td>
        <td><input type="text" name="page" id="" value="{{ $book->page }}" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Year</label></td>
        <td><input type="text" name="year" id="" value="{{ $book->year }}" class="form-control"></td>
    </tr>
</table>
<input type="submit" value="Update" class="btn btn-primary">
<a class="btn btn-danger" href="{{ route('books.index') }}">Back To Index</a>
</form>

@endsection
