@extends('books.layout')

@section('content')

<h1><strong>{{ $book->author }}</strong></h1>

<p>Written By : {{ $book->author }}</p>
<p>Number of Pages : {{ $book->page }}</p>
<p>Published On : {{ $book->year }}</p>

<a class="btn btn-primary" href="{{ route('books.index') }}">Back To Index</a>
@endsection
