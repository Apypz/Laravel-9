@extends('books.layout')
@section('content')
<table class="table table-striped">

    <tr class="table-dark">
        <th>Id</th>
        <th>Title</th>
        <th>Author</th>
        <th>Page</th>
        <th>Year</th>
        <th class="text-center">Action</th>
    </tr>
    @foreach ($books as $b)
    <tr>
        <td>{{ $b->id }}</td>
        <td>{{ $b->title}}</td>
        <td>{{ $b->author }}</td>
        <td>{{ $b->page }}</td>
        <td>{{ $b->year }}</td>
        <td class="text-center">
            <a class="btn btn-danger" href="{{ route('books.show', $b->id) }}">Show</a>
            <a class="btn btn-warning" href="{{ route('books.edit', $b->id) }}">Edit</a>

           <form onclick="return confirm('Are you?')" action="{{ route('books.destroy', $b->id) }}" method="post" style="display: inline">

                @csrf
                @method('DELETE')
                <button class="btn btn-outline-danger">Delete</button>

            </form>
        </td>

    @endforeach
</table>
<a href="{{ route('books.create') }}"><button class="btn btn-primary">Add</button></a>
@endsection


