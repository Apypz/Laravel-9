@extends('books.layout')

@section('content')

<form action="{{ route('books.store') }}" method="post">

    @csrf

<table class="table">
    <tr>
        <td><label for="">Title</label></td>
        <td><input type="text" name="title" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Author</label></td>
        <td><input type="text" name="author" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Page</label></td>
        <td><input type="text" name="page" id="" class="form-control"></td>
    </tr>
    <tr>
        <td><label for="">Year</label></td>
        <td><input type="text" name="year" id="" class="form-control"></td>
    </tr>
</table>
<input type="submit" value="Tambah" class="btn btn-primary">
</form>

@endsection
